"""Counterfactual edit suggestions.

For each requirement that is missing or only partially met, this module suggests
an edit that would improve the match score without fabricating new information.
The suggestion strategy is very simple: it looks for related lines in the
resume and suggests moving them up or rephrasing them to better align with
the job requirement.  If no related lines exist, it suggests acquiring the
skill and adding a project to demonstrate it.
"""

from typing import Dict, List


def generate_counterfactuals(evaluations: List[Dict[str, object]], resume: Dict[str, object]) -> List[str]:
    """Generate human‑readable suggestions for improving the match.

    Args:
        evaluations: List of requirement evaluation dicts from `evaluate_requirements`.
        resume: Parsed resume dict.

    Returns:
        A list of suggestion strings.
    """
    suggestions = []
    for ev in evaluations:
        req = ev["requirement"]
        status = ev["status"]
        evidence = ev.get("evidence", [])
        # Only suggest if not fully met
        if status == "Met":
            continue
        if evidence:
            # Suggest moving the evidence lines earlier in the resume to highlight them
            first_line = evidence[0]
            suggestions.append(
                f"Highlight your experience relevant to '{req}' earlier in your resume.  For example, move or rephrase: '{first_line}'."
            )
        else:
            # Suggest acquiring the skill or building a project
            suggestions.append(
                f"Consider acquiring the skill '{req}' and showcasing it through a project.  Once you have experience, add a concise bullet describing what you built and the impact."
            )
    return suggestions