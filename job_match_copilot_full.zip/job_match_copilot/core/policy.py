"""Action policy based on match score.

The action policy takes the final match score and confidence and decides what
next step to recommend: interview, request additional information or suggest
a targeted improvement plan.  Thresholds (tau1, tau0) can be tweaked to
control the aggressiveness of the recommendations.
"""

from typing import Dict, List


def decide_action(score: float, confidence: float, suggestions: List[str]) -> Dict[str, object]:
    """Return an action recommendation.

    Args:
        score: The match score (0–1).
        confidence: A proxy for confidence (0–1).
        suggestions: List of counterfactual edit suggestions.

    Returns:
        A dict with `action` and possibly `details` (list or str).
    """
    # Tunable thresholds
    tau1 = 0.8  # high bar for interview
    tau0 = 0.5  # minimum bar for request information
    if score >= tau1 and confidence >= 0.7:
        return {"action": "Interview", "details": "Candidate strongly matches requirements."}
    elif score >= tau0:
        return {
            "action": "Request clarifications",
            "details": "Good potential; ask for portfolio or code samples that demonstrate the missing skills.",
        }
    else:
        return {
            "action": "Targeted improvement",
            "details": suggestions,
        }