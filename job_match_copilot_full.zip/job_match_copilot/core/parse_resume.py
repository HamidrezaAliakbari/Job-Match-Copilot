"""Simple resume parser.

The goal of this module is to normalise a resume into a dictionary of key fields.  For the purposes
of this starter, we assume the resume is a plain‑text file.  If you wish to support PDFs
you can integrate a library such as PyPDF2 or pdfminer later.

The returned dictionary has keys:

* `text` – the full textual content of the resume.
* `lines` – a list of lines for easier processing.
* `skills` – a list of detected skill keywords (lowercase).
* `experience_years` – approximate years of experience if extractable.
* `education` – list of education entries.
"""

import re
from pathlib import Path
from typing import Dict, List


SKILL_KEYWORDS = {
    "python",
    "pandas",
    "scikit-learn",
    "machine learning",
    "sql",
    "tensorflow",
    "pytorch",
    "data analysis",
    "data scientist",
    "deep learning",
}

EXPERIENCE_PATTERN = re.compile(r"(\d+)\+?\s+years?")


def parse_resume(file_path: str) -> Dict[str, object]:
    """Parse a plain‑text resume into a normalised dictionary.

    Args:
        file_path: Path to a text file containing the resume.

    Returns:
        A dict with keys `text`, `lines`, `skills`, `experience_years`, `education`.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Resume file not found: {file_path}")
    text = path.read_text(encoding="utf-8")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    # extract skills by scanning for keywords
    text_lower = text.lower()
    skills = sorted({kw for kw in SKILL_KEYWORDS if kw in text_lower})
    # extract approximate years of experience
    years_match = EXPERIENCE_PATTERN.search(text_lower)
    experience_years = int(years_match.group(1)) if years_match else None
    # naive education extraction: lines containing degree keywords
    edu_keywords = {"b.s.", "bachelor", "m.s.", "master", "ph.d.", "phd", "university"}
    education = [ln for ln in lines if any(k in ln.lower() for k in edu_keywords)]
    return {
        "text": text,
        "lines": lines,
        "skills": skills,
        "experience_years": experience_years,
        "education": education,
    }