"""Lightweight reasoning functions to classify requirements and extract evidence.

This module replaces the need for a large language model in this demo.  It takes
a list of job requirements and a parsed resume, then determines whether each
requirement is met, partially met or missing, along with evidence lines pulled
from the resume.
"""

import re
from typing import Dict, List, Tuple

from .retrieve import retrieve_evidence


def _tokenise(text: str) -> List[str]:
    """Tokenise a string into lowercase words."""
    # Split on non‑alphanumeric characters
    return re.findall(r"\b\w+\b", text.lower())


def evaluate_requirements(requirements: List[str], resume: Dict[str, object]) -> List[Dict[str, object]]:
    """Evaluate each requirement against the resume.

    Args:
        requirements: List of job requirement strings.
        resume: Parsed resume dict from `parse_resume`.

    Returns:
        A list of dicts containing `requirement`, `status` and `evidence` (list of strings).
    """
    results = []
    resume_text = resume.get("text", "").lower()
    resume_lines = resume.get("lines", [])
    for req in requirements:
        tokens = _tokenise(req)
        if not tokens:
            results.append({"requirement": req, "status": "Unknown", "evidence": []})
            continue
        # Determine if all tokens are present in the resume text
        token_presence = [tok in resume_text for tok in tokens]
        if all(token_presence):
            status = "Met"
        elif any(token_presence):
            status = "Partially met"
        else:
            status = "Missing"
        evidence = retrieve_evidence(resume_lines, req, top_k=3)
        results.append({"requirement": req, "status": status, "evidence": evidence})
    return results