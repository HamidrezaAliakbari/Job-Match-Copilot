"""Simple job description parser.

This module reads a job description from a text file and extracts lists of
requirements and preferred qualifications.  It relies on the caller to provide
the lists of requirements and preferred terms when submitting a scoring request
(see `sample_data/sample_request.json`).  However the parser can also attempt
to extract bullet lists starting with `*` if present.
"""

from pathlib import Path
from typing import Dict, List, Optional


def parse_job(file_path: str, requirements: Optional[List[str]] = None, preferred: Optional[List[str]] = None) -> Dict[str, object]:
    """Parse a job description file.

    Args:
        file_path: Path to the text file containing the job description.
        requirements: Optional list of explicit requirement strings.
        preferred: Optional list of preferred (nice‑to‑have) strings.

    Returns:
        A dict with keys `text`, `lines`, `requirements`, `preferred`.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Job description file not found: {file_path}")
    text = path.read_text(encoding="utf-8")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    # If requirements list not provided, attempt to extract lines starting with '* '
    extracted_reqs = []
    extracted_pref = []
    bullet_points = [ln.lstrip('*').strip() for ln in lines if ln.lstrip().startswith('*')]
    if requirements is None:
        extracted_reqs = bullet_points
    else:
        extracted_reqs = requirements
    if preferred is None:
        extracted_pref = []
    else:
        extracted_pref = preferred
    return {
        "text": text,
        "lines": lines,
        "requirements": extracted_reqs,
        "preferred": extracted_pref,
    }