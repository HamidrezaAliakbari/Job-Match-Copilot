"""Scoring utilities.

This module contains functions to compute a match score and confidence given
requirement evaluation results and optionally metadata from the resume and job
description.

The scoring scheme here is intentionally simple.  Each requirement that is
fully met contributes 1 point, each partially met contributes 0.5 points and
missing contributes 0.  The final score is the fraction of achieved points
over the maximum possible points.  Confidence is heuristically determined
based on how many tokens matched per requirement.  In a production system
you should calibrate these values using logistic regression or other
techniques.
"""

from typing import Dict, List


def compute_match_score(evaluations: List[Dict[str, object]]) -> Dict[str, float]:
    """Compute an overall match score and confidence.

    Args:
        evaluations: Output of `evaluate_requirements` – list of dicts with
            `status` and `requirement`.

    Returns:
        A dict with `score` (0–1 float) and `confidence` (0–1 float).
    """
    total = len(evaluations)
    if total == 0:
        return {"score": 0.0, "confidence": 0.0}
    points = 0.0
    token_matches = 0
    token_total = 0
    for ev in evaluations:
        status = ev.get("status")
        if status == "Met":
            points += 1.0
        elif status == "Partially met":
            points += 0.5
        # Count tokens matched for rough confidence
        evidence = ev.get("evidence", [])
        if evidence:
            token_matches += 1
        token_total += 1
    score = points / total
    confidence = token_matches / token_total if token_total > 0 else 0.0
    return {"score": round(score, 3), "confidence": round(confidence, 3)}