"""FastAPI application for the Job‑Match Copilot demo."""

from fastapi import FastAPI, HTTPException

from core.parse_resume import parse_resume
from core.parse_job import parse_job
from core.reason_llm import evaluate_requirements
from core.score import compute_match_score
from core.counterfactual import generate_counterfactuals
from core.policy import decide_action

from .schemas import (
    ScoreRequest,
    ScoreResponse,
    CounterfactualResponse,
    ActionResponse,
    RequirementResult,
)

app = FastAPI(title="Job‑Match Copilot", version="0.1.0")


@app.post("/score", response_model=ScoreResponse)
def score_match(request: ScoreRequest) -> ScoreResponse:
    """Compute a match score and evidence for a resume vs. job description."""
    try:
        resume = parse_resume(request.resume_path)
        job = parse_job(request.job_path, requirements=request.requirements, preferred=request.preferred)
    except FileNotFoundError as e:
        raise HTTPException(status_code=400, detail=str(e))
    evaluations = evaluate_requirements(job["requirements"], resume)
    # convert to Pydantic models
    eval_models = [RequirementResult(**ev) for ev in evaluations]
    score_dict = compute_match_score(evaluations)
    return ScoreResponse(score=score_dict["score"], confidence=score_dict["confidence"], evaluations=eval_models)


@app.post("/counterfactual", response_model=CounterfactualResponse)
def counterfactual(request: ScoreRequest) -> CounterfactualResponse:
    """Generate edit suggestions for improving the match score."""
    try:
        resume = parse_resume(request.resume_path)
        job = parse_job(request.job_path, requirements=request.requirements, preferred=request.preferred)
    except FileNotFoundError as e:
        raise HTTPException(status_code=400, detail=str(e))
    evaluations = evaluate_requirements(job["requirements"], resume)
    suggestions = generate_counterfactuals(evaluations, resume)
    return CounterfactualResponse(suggestions=suggestions)


@app.post("/action", response_model=ActionResponse)
def action_recommendation(request: ScoreRequest) -> ActionResponse:
    """Recommend the next best action based on score, confidence and suggestions."""
    try:
        resume = parse_resume(request.resume_path)
        job = parse_job(request.job_path, requirements=request.requirements, preferred=request.preferred)
    except FileNotFoundError as e:
        raise HTTPException(status_code=400, detail=str(e))
    evaluations = evaluate_requirements(job["requirements"], resume)
    score_dict = compute_match_score(evaluations)
    suggestions = generate_counterfactuals(evaluations, resume)
    action = decide_action(score_dict["score"], score_dict["confidence"], suggestions)
    return ActionResponse(**action)