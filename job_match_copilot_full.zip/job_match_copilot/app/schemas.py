"""Pydantic schemas for API requests and responses."""

from typing import List, Optional
from pydantic import BaseModel


class ScoreRequest(BaseModel):
    resume_path: str
    job_path: str
    requirements: List[str]
    preferred: Optional[List[str]] = None


class RequirementResult(BaseModel):
    requirement: str
    status: str
    evidence: List[str]


class ScoreResponse(BaseModel):
    score: float
    confidence: float
    evaluations: List[RequirementResult]


class CounterfactualResponse(BaseModel):
    suggestions: List[str]


class ActionResponse(BaseModel):
    action: str
    details: Optional[object] = None